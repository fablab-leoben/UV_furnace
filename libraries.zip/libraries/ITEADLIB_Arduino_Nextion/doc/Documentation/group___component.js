var group___component =
[
    [ "NexButton", "class_nex_button.html", [
      [ "NexButton", "class_nex_button.html#a57d346614059bac40aff955a0dc9d76a", null ],
      [ "getText", "class_nex_button.html#a5ba1f74aa94b41b98172e42583ee13d6", null ],
      [ "setText", "class_nex_button.html#a649dafc5afb1dc7f1fc1bde1e6270290", null ]
    ] ],
    [ "NexCrop", "class_nex_crop.html", [
      [ "NexCrop", "class_nex_crop.html#a1a3a195d3da05cb832f91a2ef43f27d3", null ],
      [ "getPic", "class_nex_crop.html#a2cbfe125182626965dd530f14ab55885", null ],
      [ "setPic", "class_nex_crop.html#aac34fc2f8ead1e330918089ea8a339db", null ]
    ] ],
    [ "NexDSButton", "class_nex_d_s_button.html", [
      [ "NexDSButton", "class_nex_d_s_button.html#a226edd2467f2fdf54848f5235b808e2b", null ],
      [ "getValue", "class_nex_d_s_button.html#a63e08f9a79f326c47aa66e1d0f9648c8", null ],
      [ "setValue", "class_nex_d_s_button.html#a2f696207609e0f01aadebb8b3826b0fa", null ]
    ] ],
    [ "NexGauge", "class_nex_gauge.html", [
      [ "NexGauge", "class_nex_gauge.html#ac79040067d42f7f1ba16cc4a1dfd8b9b", null ],
      [ "getValue", "class_nex_gauge.html#aeea8933513ebba11584ad97f8c8b5e69", null ],
      [ "setValue", "class_nex_gauge.html#a448ce9ad69f54c156c325d578a96b765", null ]
    ] ],
    [ "NexHotspot", "class_nex_hotspot.html", [
      [ "NexHotspot", "class_nex_hotspot.html#ad2408e74f5445941897702c4c78fddbf", null ]
    ] ],
    [ "NexNumber", "class_nex_number.html", [
      [ "NexNumber", "class_nex_number.html#a59c2ed35b787f498e7fbc54eff71d00b", null ],
      [ "getValue", "class_nex_number.html#ad184ed818666ec482efddf840185c7b8", null ],
      [ "setValue", "class_nex_number.html#a9cef51f6b76b4ba03a31b2427ffd4526", null ]
    ] ],
    [ "NexPage", "class_nex_page.html", [
      [ "NexPage", "class_nex_page.html#a8608a0400bd8e27466ca4bbc05b5c2a0", null ],
      [ "show", "class_nex_page.html#a5714e41d4528b991eda4bbe578005418", null ]
    ] ],
    [ "NexPicture", "class_nex_picture.html", [
      [ "NexPicture", "class_nex_picture.html#aa6096defacd933e8bff5283c83200459", null ],
      [ "getPic", "class_nex_picture.html#a11bd68ef9fe1d03d9e0d02ef1c7527e9", null ],
      [ "setPic", "class_nex_picture.html#ab1c6adff615d48261ce10c2095859abd", null ]
    ] ],
    [ "NexProgressBar", "class_nex_progress_bar.html", [
      [ "NexProgressBar", "class_nex_progress_bar.html#a61f76f0c855c7839630dbc930e3401d8", null ],
      [ "getValue", "class_nex_progress_bar.html#a3e5eb13b2aa014c8f6a9e16439917bf2", null ],
      [ "setValue", "class_nex_progress_bar.html#aaa7937d364cb63151bd1e1bc4729334d", null ]
    ] ],
    [ "NexSlider", "class_nex_slider.html", [
      [ "NexSlider", "class_nex_slider.html#a00c5678209c936e9a57c14b6e2384774", null ],
      [ "getValue", "class_nex_slider.html#a384d5488b421efd6affbfd32f45bb107", null ],
      [ "setValue", "class_nex_slider.html#a3f325bda4db913e302e94a4b25de7b5f", null ]
    ] ],
    [ "NexText", "class_nex_text.html", [
      [ "NexText", "class_nex_text.html#a38b4dd752d39bfda4ef7642b43ded91a", null ],
      [ "getText", "class_nex_text.html#a9cf417b2f25df2872492c55bdc9f5b30", null ],
      [ "setText", "class_nex_text.html#a19589b32c981436a1bbcfe407bc766e3", null ]
    ] ],
    [ "NexTimer", "class_nex_timer.html", [
      [ "NexTimer", "class_nex_timer.html#a5cb6cdcf0d7e46723364d486d4dcd650", null ],
      [ "attachTimer", "class_nex_timer.html#ae6f1ae95ef40b8bc6f482185b1ec5175", null ],
      [ "detachTimer", "class_nex_timer.html#a365d08df4623ce8a146e73ff9204d5cb", null ],
      [ "disable", "class_nex_timer.html#ae016d7d39ede6cf813221b26691809f1", null ],
      [ "enable", "class_nex_timer.html#a01c146befad40fc0321891ac69e75710", null ],
      [ "getCycle", "class_nex_timer.html#afd95e7490e28e2a36437be608f26b40e", null ],
      [ "setCycle", "class_nex_timer.html#acf20f76949ed43f05b1c33613dabcb01", null ]
    ] ],
    [ "NexWaveform", "class_nex_waveform.html", [
      [ "NexWaveform", "class_nex_waveform.html#a4f18ca5050823e874d526141c8595514", null ],
      [ "addValue", "class_nex_waveform.html#a5b04ea7397b784947b845e2a03fc77e4", null ]
    ] ]
];