var class_nex_number =
[
    [ "NexNumber", "class_nex_number.html#a59c2ed35b787f498e7fbc54eff71d00b", null ],
    [ "getValue", "class_nex_number.html#ad184ed818666ec482efddf840185c7b8", null ],
    [ "setValue", "class_nex_number.html#a9cef51f6b76b4ba03a31b2427ffd4526", null ]
];