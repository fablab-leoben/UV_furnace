var examples =
[
    [ "CompButton.ino", "_comp_button_8ino-example.html", null ],
    [ "CompCrop.ino", "_comp_crop_8ino-example.html", null ],
    [ "CompDualStateButton.ino", "_comp_dual_state_button_8ino-example.html", null ],
    [ "CompGauge.ino", "_comp_gauge_8ino-example.html", null ],
    [ "CompHotspot.ino", "_comp_hotspot_8ino-example.html", null ],
    [ "CompNumber.ino", "_comp_number_8ino-example.html", null ],
    [ "CompPage.ino", "_comp_page_8ino-example.html", null ],
    [ "CompPicture.ino", "_comp_picture_8ino-example.html", null ],
    [ "CompProgressBar.ino", "_comp_progress_bar_8ino-example.html", null ],
    [ "CompSlider.ino", "_comp_slider_8ino-example.html", null ],
    [ "CompText.ino", "_comp_text_8ino-example.html", null ],
    [ "CompTimer.ino", "_comp_timer_8ino-example.html", null ],
    [ "CompWaveform.ino", "_comp_waveform_8ino-example.html", null ]
];