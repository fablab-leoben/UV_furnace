var annotated =
[
    [ "NexButton", "class_nex_button.html", "class_nex_button" ],
    [ "NexCrop", "class_nex_crop.html", "class_nex_crop" ],
    [ "NexDSButton", "class_nex_d_s_button.html", "class_nex_d_s_button" ],
    [ "NexGauge", "class_nex_gauge.html", "class_nex_gauge" ],
    [ "NexHotspot", "class_nex_hotspot.html", "class_nex_hotspot" ],
    [ "NexNumber", "class_nex_number.html", "class_nex_number" ],
    [ "NexObject", "class_nex_object.html", "class_nex_object" ],
    [ "NexPage", "class_nex_page.html", "class_nex_page" ],
    [ "NexPicture", "class_nex_picture.html", "class_nex_picture" ],
    [ "NexProgressBar", "class_nex_progress_bar.html", "class_nex_progress_bar" ],
    [ "NexSlider", "class_nex_slider.html", "class_nex_slider" ],
    [ "NexText", "class_nex_text.html", "class_nex_text" ],
    [ "NexTimer", "class_nex_timer.html", "class_nex_timer" ],
    [ "NexTouch", "class_nex_touch.html", "class_nex_touch" ],
    [ "NexWaveform", "class_nex_waveform.html", "class_nex_waveform" ]
];